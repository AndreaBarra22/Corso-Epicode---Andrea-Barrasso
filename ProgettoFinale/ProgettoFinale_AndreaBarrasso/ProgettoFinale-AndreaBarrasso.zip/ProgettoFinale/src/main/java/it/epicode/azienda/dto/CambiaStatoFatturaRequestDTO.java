package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CambiaStatoFatturaRequestDTO {
	@NotNull(message = "il campo numero non deve essere vuoto")
	private Long numero;
	@NotBlank(message = "il campo stato fattura")
	private String statoFattura;

}
