package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EliminaSedeOperativaRequestDTO {
	@NotNull(message = "il campo non deve essere vuoto!")
	 private Long id;
}
