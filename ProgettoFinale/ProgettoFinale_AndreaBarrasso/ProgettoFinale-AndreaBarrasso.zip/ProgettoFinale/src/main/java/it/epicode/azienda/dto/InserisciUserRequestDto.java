package it.epicode.azienda.dto;

import java.util.Set;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciUserRequestDto {
@NotBlank
	private String username;
@NotBlank
	private String password;
@NotBlank
	private String email;
	 private String nome;
	 private String cognome;
	
	

}
