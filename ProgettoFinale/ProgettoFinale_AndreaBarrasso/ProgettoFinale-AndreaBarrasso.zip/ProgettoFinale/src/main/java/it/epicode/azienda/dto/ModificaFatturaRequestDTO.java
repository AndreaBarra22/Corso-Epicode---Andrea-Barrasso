package it.epicode.azienda.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaFatturaRequestDTO {
	static final String DATE_PATTERN ="dd/MM/yyyy";
	@NotNull(message = "il campo numero non deve essere vuoto")
	private Long numero;
	@Schema(example = "20/02/2000", type = "string")	
	@JsonFormat(pattern = DATE_PATTERN)
	private LocalDate data;
	@NotNull(message = "il campo importo non deve essere vuoto")
	private double importo;
	@NotBlank(message = "il campo stato fattura non deve essere vuoto")
	private String statoFattura;
	@NotNull(message = "il campo id cliente non deve essere vuoto")
	private Long idCliente;
	

}
