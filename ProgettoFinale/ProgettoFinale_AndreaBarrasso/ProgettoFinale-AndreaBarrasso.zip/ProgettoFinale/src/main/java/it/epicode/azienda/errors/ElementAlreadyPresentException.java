package it.epicode.azienda.errors;

/**
 * creazione eccezione  per un elemento gia presente
 */
public class ElementAlreadyPresentException extends Exception {

	public ElementAlreadyPresentException(String message) {
		super(message);

	}


}
