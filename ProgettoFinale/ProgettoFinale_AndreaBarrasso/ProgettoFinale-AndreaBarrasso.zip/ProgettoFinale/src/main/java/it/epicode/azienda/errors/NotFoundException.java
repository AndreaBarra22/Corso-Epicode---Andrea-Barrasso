package it.epicode.azienda.errors;
/**
 * creazione eccezione per un elemento non trovato
 */
public class NotFoundException extends Exception {

	public NotFoundException(String message) {
		super(message);

	}

}
