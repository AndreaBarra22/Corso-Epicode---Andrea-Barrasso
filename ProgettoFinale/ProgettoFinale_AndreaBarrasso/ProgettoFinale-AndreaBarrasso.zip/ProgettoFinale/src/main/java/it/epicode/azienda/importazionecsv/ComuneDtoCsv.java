package it.epicode.azienda.importazionecsv;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ComuneDtoCsv {
	
	@JsonProperty("comune")
	private String nome;
	@JsonProperty("Provincia")
	private String provincia;
	@JsonProperty("CAP")
	private String cap;

}
