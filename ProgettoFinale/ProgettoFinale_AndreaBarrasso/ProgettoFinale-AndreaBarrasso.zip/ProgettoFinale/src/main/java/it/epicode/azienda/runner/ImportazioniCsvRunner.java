package it.epicode.azienda.runner;
import java.io.File;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import it.epicode.azienda.importazionecsv.ComuneDtoCsv;
import it.epicode.azienda.importazionecsv.ProvinciaDtoCsv;
import it.epicode.azienda.model.Comune;
import it.epicode.azienda.model.Provincia;
import it.epicode.azienda.repository.ComuneRepository;
import it.epicode.azienda.repository.ProvinciaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;




//@Component //disabilitato per pkey duplicato 
@Slf4j
public class ImportazioniCsvRunner implements ApplicationRunner {
@Autowired
ProvinciaRepository pr;
@Autowired
ComuneRepository cr;
	
	@Override
	public void run(ApplicationArguments args) throws Exception {

		String fileProvinciaCSV = "csv/province-italiane.csv";
		CsvSchema provinciaCSVSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader();
		CsvMapper mapper = new CsvMapper();
		File fileProvincia = new ClassPathResource(fileProvinciaCSV).getFile();
		MappingIterator<List<String>> valueReader = mapper
				.reader(ProvinciaDtoCsv.class)
				.with(provinciaCSVSchema)
				.readValues(fileProvincia);
		for (Object o : valueReader.readAll()) {
			Provincia cl = new Provincia();
			ProvinciaDtoCsv csvProvinvcia =(ProvinciaDtoCsv)o;
			if(csvProvinvcia.getSigla() == null && csvProvinvcia.getSigla() == "SA") continue;
			BeanUtils.copyProperties(o, cl);
			pr.save(cl);
		}
		
		String fileComuneCSV = "csv/comuni.csv";
		CsvSchema comuneCSVSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader();
		CsvMapper mapper2 = new CsvMapper();
		File fileComune = new ClassPathResource(fileComuneCSV).getFile();
		MappingIterator<List<String>> valueReader2 = mapper2
				.reader(ComuneDtoCsv.class)
				.with(comuneCSVSchema)
				.readValues(fileComune);
		for (Object o : valueReader2.readAll()) {
			Comune cl = new Comune();
			ComuneDtoCsv csvComune = (ComuneDtoCsv)o;
			if(csvComune.getProvincia() == null) continue;
			Optional<Provincia> p = pr.findById(csvComune.getProvincia());
			if(p.isPresent()) {
			cl.setProvincia(p.get());
			BeanUtils.copyProperties(o, cl);}
			
			if(cl.getCap() != null) {
			cr.save(cl);}
		}
	}



}
