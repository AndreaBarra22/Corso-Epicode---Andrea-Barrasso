package it.epicode.azienda.services;



import org.springframework.beans.BeanUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.EliminaComuneRequestDTO;
import it.epicode.azienda.dto.InserisciComuneRequestDTO;
import it.epicode.azienda.dto.ModificaComuneRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Comune;
import it.epicode.azienda.model.Provincia;
import it.epicode.azienda.repository.ComuneRepository;
import it.epicode.azienda.repository.ProvinciaRepository;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ComuneService {
	@Autowired
	ComuneRepository cr;
	@Autowired
	ProvinciaRepository pr;

	/**
	 * inserimento di un comune nel db usando un dto con associazione della provincia con possibilita di paginazione attraverso il request mapping POST
	 * @param dto
	 * @throws NotFoundException
	 * @throws ElementAlreadyPresentException 
	 */
	public void inserisciComune(InserisciComuneRequestDTO dto) throws NotFoundException{
		log.info("==================siamo nel service inserisci comune====================");
		log.info("cap " + dto.getCap());
		log.info("nome " + dto.getNome());
		Comune c = new Comune();
		BeanUtils.copyProperties(dto, c);
		if(pr.existsById(dto.getSiglaProvincia())) {
			log.info("siglia provincia " + dto.getSiglaProvincia());
			Provincia p = pr.findById(dto.getSiglaProvincia()).get();
			c.setProvincia(p);
			p.getComune().add(c);
			cr.save(c);
		}
		else {
			throw new NotFoundException("provincia non trovata");
		}
	}

	/**
	 * eliminazione di un comune attrverso la ricerca dell'id attraverso il request mapping DELETE
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaComune(EliminaComuneRequestDTO dto) throws NotFoundException {
		log.info("==================siamo nel service elimina comune====================");
		if(cr.existsById(dto.getId())) {
			log.info("id comune "+ dto.getId().toString());
			cr.deleteById(dto.getId());
		}
		else {
			throw new NotFoundException("comune non trovato");
		}

	}

	/**
	 * modifica di un comune con associazione della provincia attraverso il request mapping PUT
	 * @param dto
	 * @throws NotFoundException
	 */
	public void modificaComune(ModificaComuneRequestDTO dto) throws NotFoundException {
		log.info("==================siamo nel service modifica comune====================");
		if(cr.existsById(dto.getId())) {
			log.info("id comune " + dto.getId().toString());
			log.info("cap " + dto.getCap());
			log.info("nome " + dto.getNome());
			Comune c = cr.findById(dto.getId()).get();
			BeanUtils.copyProperties(dto, c);
			if(pr.existsById(dto.getSiglaProvincia())) {
				log.info("sigla provincia " + dto.getSiglaProvincia());
				Provincia p = pr.findById(dto.getSiglaProvincia()).get();
				p.getComune().add(c);
				c.setProvincia(p);
				cr.save(c);
			}else {
				throw new NotFoundException("provincia non trovata");
			}

		}else {
			throw new NotFoundException("comune non trovato");
		}
	}

	/**
	 * ricerca dei comune con possibilita di paginazione attraverso il request mapping GET
	 * @param page
	 * @return
	 */
	public Page cercaComune(Pageable page) {
		log.info("==================siamo nel service cerca comune====================");
		return cr.findAll(page);

	}


	/**
	 * ricerca comune tramite la ricerca del nome con possibilita di paginazione attraverso il request maping GET
	 * @param page
	 * @param nome
	 * @return
	 */
	public Page cercaComuneNome(Pageable page,String nome) {
		log.info("==================siamo nel service cerca comune con nome====================");
		log.info("nome comune " + nome);
		return cr.findByNomeContaining(page, nome);
	}








}
