package it.epicode.azienda.sedeperativatest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.EliminaSedeLegaleRequestDTO;
import it.epicode.azienda.dto.EliminaSedeOperativaRequestDTO;
import it.epicode.azienda.dto.InserisciSedeLegaleRequestDTO;
import it.epicode.azienda.dto.InserisciSedeOperativaRequestDTO;
import it.epicode.azienda.dto.ModificaSedeLegaleRequestDTO;
import it.epicode.azienda.dto.ModificaSedeOperativaRequestDTO;

public class SedeOperativaControllerTest extends BasicTests{

	@Override
	protected String getEntryPoint() {
		
		return "/sedeoperativa";
	}
	@Test
	void getAllSedeOperativa() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedioperative", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);}
	@Test
	void getAllSedeOperativaKo() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tuttesedioperative", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllSedeOperativaNotAuth() {
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tuttesedioperative", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllSedeOperativaVia() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedioperativevia/Via Como", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllSedeOperativaViaKo() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedioperativevia/Via Como", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllSedeOperativaNomeNotFound() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedioperativevia/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllSedeOperativaNomeNotAuth() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedioperativevia/Via Como", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}	
	@Test
	void inserisciSedeOperativa() {
		InserisciSedeOperativaRequestDTO dto =new InserisciSedeOperativaRequestDTO ();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(1l);
		HttpEntity<InserisciSedeOperativaRequestDTO>entity = new HttpEntity<InserisciSedeOperativaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedeoperativa",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void inserisciSedeOperativaKo() {
		InserisciSedeOperativaRequestDTO dto =new InserisciSedeOperativaRequestDTO ();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(1l);
		HttpEntity<InserisciSedeOperativaRequestDTO>entity = new HttpEntity<InserisciSedeOperativaRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedeoperativa",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void inserisciSedeOperativaNotAuth() {
		InserisciSedeOperativaRequestDTO dto =new InserisciSedeOperativaRequestDTO ();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(1l);
		HttpEntity<InserisciSedeOperativaRequestDTO>entity = new HttpEntity<InserisciSedeOperativaRequestDTO>(dto);
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedeoperativa",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void inserisciSedeOperativaNotFound() {
		InserisciSedeOperativaRequestDTO dto =new InserisciSedeOperativaRequestDTO ();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(1333333333l);
		HttpEntity<InserisciSedeOperativaRequestDTO>entity = new HttpEntity<InserisciSedeOperativaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedeoperativa",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void modificaSedeOperativa() {
		ModificaSedeOperativaRequestDTO dto =  new 	ModificaSedeOperativaRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(2l);
		
		HttpEntity<ModificaSedeOperativaRequestDTO >entity = new HttpEntity<ModificaSedeOperativaRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedeoperativa",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void modificaSedeOperativaKo() {
		ModificaSedeOperativaRequestDTO dto =  new 	ModificaSedeOperativaRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(2l);
		
		HttpEntity<ModificaSedeOperativaRequestDTO >entity = new HttpEntity<ModificaSedeOperativaRequestDTO >(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedeoperativa",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void modificaSedeOperativaNotAuth() {
		ModificaSedeOperativaRequestDTO dto =  new 	ModificaSedeOperativaRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(2l);
		
		HttpEntity<ModificaSedeOperativaRequestDTO >entity = new HttpEntity<ModificaSedeOperativaRequestDTO >(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedeoperativa",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void modificaSedeOperativaSedeOperativa() {
		ModificaSedeOperativaRequestDTO dto =  new 	ModificaSedeOperativaRequestDTO();
		dto.setId(12222L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(2l);
		
		HttpEntity<ModificaSedeOperativaRequestDTO >entity = new HttpEntity<ModificaSedeOperativaRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedeoperativa",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void modificaSedeOperativaNotFoundComune() {
		ModificaSedeOperativaRequestDTO dto =  new 	ModificaSedeOperativaRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(222222l);
		
		HttpEntity<ModificaSedeOperativaRequestDTO >entity = new HttpEntity<ModificaSedeOperativaRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedeoperativa",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void eliminaSedeOperativa() {
		EliminaSedeOperativaRequestDTO dto = new EliminaSedeOperativaRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeOperativaRequestDTO>entity = new HttpEntity<EliminaSedeOperativaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedeoperativa",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void eliminaSedeOperativaKo() {
		EliminaSedeOperativaRequestDTO dto = new EliminaSedeOperativaRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeOperativaRequestDTO>entity = new HttpEntity<EliminaSedeOperativaRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedeoperativa",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaSedeOperativaNotAuth() {
		EliminaSedeOperativaRequestDTO dto = new EliminaSedeOperativaRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeOperativaRequestDTO>entity = new HttpEntity<EliminaSedeOperativaRequestDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedeoperativa",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void eliminaSedeOperativaNotFound() {
		EliminaSedeOperativaRequestDTO dto = new EliminaSedeOperativaRequestDTO();
		dto.setId(23232323L);
		HttpEntity<EliminaSedeOperativaRequestDTO>entity = new HttpEntity<EliminaSedeOperativaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedeoperativa",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}

}
