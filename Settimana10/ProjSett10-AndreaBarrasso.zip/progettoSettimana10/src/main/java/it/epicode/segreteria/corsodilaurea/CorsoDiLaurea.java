package it.epicode.segreteria.corsodilaurea;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import it.epicode.segreteria.studente.Studente;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Valid
public class CorsoDiLaurea {
@Id
@NotBlank
private  String codice;
@NotBlank
private String nomeCorso;
private String indirizzo;
@Min(10)
private int numeroDiEsami;

@OneToMany(mappedBy = "corso", cascade = CascadeType.ALL)
private List<Studente>studenti;
}
