package it.epicode.segreteria.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.segreteria.corsodilaurea.CorsoDiLaurea;
import it.epicode.segreteria.corsodilaurea.CorsoDiLaureaRepository;
import it.epicode.segreteria.studente.Studente;
import it.epicode.segreteria.studente.StudenteRepository;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SegreteriaService {
@Autowired
StudenteRepository sr;
@Autowired
CorsoDiLaureaRepository cr;



	public List<Studente> getAllStudenti(){
		return (List<Studente>) sr.findAll(); 	
	}
	
	public List<CorsoDiLaurea> getAllCorsi(){
		return (List<CorsoDiLaurea>) cr.findAll(); 	
	}
	
	
	public void inserisciStudente(Studente studente) {
		if(!sr.existsById(studente.getMatricola())) {
			sr.save(studente);
		}
	}
	public void inserisciCorso(CorsoDiLaurea corso) {
		if(!sr.existsById(corso.getCodice())) {
			cr.save(corso);
		}
}
	public Studente TrovaStudenteid(String matricola) {
		if(sr.existsById(matricola)){
		Studente studente= sr.findById(matricola).get();
		return studente;

			
		}
		return null;
	}
	
	
	public void modificaStudente(Studente studente) {
		if(sr.existsById(studente.getMatricola())) {
			sr.findById(studente.getMatricola()).get();
			sr.save(studente);
		}
	}
	public void modificaCorso(CorsoDiLaurea corso) {
		if(cr.existsById(corso.getCodice())) {
			cr.findById(corso.getCodice()).get();
			 cr.save(corso);
		}
	}
	
	
	public void eliminaStudente(Studente studente) {
		log.info(studente.getMatricola());
		if(sr.existsById(studente.getMatricola())) {
			sr.findById(studente.getMatricola()).get();
			sr.deleteById(studente.getMatricola());
		}
	}
	
	public CorsoDiLaurea TrovaCorsoid( String codice) {
		if(cr.existsById(codice)){
		CorsoDiLaurea corso= cr.findById(codice).get();
		return corso;
		}
		return null;
	}
	
	public void eliminaCorso(CorsoDiLaurea corso) {
		if(cr.existsById(corso.getCodice())) {
			cr.findById(corso.getCodice()).get();
			cr.deleteById(corso.getCodice());
		}
	}


}
