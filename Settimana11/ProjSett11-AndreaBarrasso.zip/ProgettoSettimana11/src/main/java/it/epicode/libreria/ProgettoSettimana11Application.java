package it.epicode.libreria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgettoSettimana11Application {

	public static void main(String[] args) {
		SpringApplication.run(ProgettoSettimana11Application.class, args);
	}

}
