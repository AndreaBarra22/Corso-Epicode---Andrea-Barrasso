package it.epicode.libreria.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.libreria.dto.InserisciAutoreRequestDto;
import it.epicode.libreria.dto.ModificaAutoreRequestDTO;
import it.epicode.libreria.errors.NotFoundException;
import it.epicode.libreria.services.AutoreService;



@RestController
@RequestMapping("/autore")
public class AutoreController {
	
	
	
	@Autowired
	AutoreService as;
	
	@Operation (summary = "Inserisce un autore nel db", description = "inserisce una autore nel db ")
	@ApiResponse(responseCode = "200" , description = "autore inserito con successo nel db !")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisciAutore" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciEdificio(@Valid @RequestBody InserisciAutoreRequestDto dto) {
		as.inserisciAutore(dto);
			return ResponseEntity.ok("autore inserito");}
	
	
	@Operation (summary = "ritorna tutti gli autori presenti nel db", description = "ritorna la lista di tutti gli autori presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista autori")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttiautori")
	public ResponseEntity tuttiILibri() {
		return ResponseEntity.ok(as.trovaTuttiAutori());
	}
	
	@Operation (summary = "modifica una autore presente nel db ", description = "modifica un autore presente nel db ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificaAutore")
	public ResponseEntity modificaLibro(@Valid @RequestBody ModificaAutoreRequestDTO dto) throws NotFoundException {
		as.modificaAutore(dto);
		return ResponseEntity.ok("Autore modificato");
	}
	
	
	@Operation (summary = "elimina un  autore presente nel db", description = "elimina un autore presente nel db ")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminaAutore/{id}")
	public ResponseEntity eliminaAutore(@PathVariable("id") Long id ) throws NotFoundException {
		as.eliminaAutore(id);
		return ResponseEntity.ok("Autore eliminato");
	}
	
	}
	

