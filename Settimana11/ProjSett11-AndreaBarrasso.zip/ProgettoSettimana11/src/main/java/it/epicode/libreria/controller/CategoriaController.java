package it.epicode.libreria.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.libreria.dto.InserisciCategoriaRequestDto;
import it.epicode.libreria.dto.ModificaCategoriaRequestDTO;
import it.epicode.libreria.errors.NotFoundException;
import it.epicode.libreria.services.CategoriaService;

@RestController
@RequestMapping("/categoria")
public class CategoriaController {
	
	
	
	@Autowired
	CategoriaService cs;
	
	
	
	@Operation (summary = "Inserisce una categoria nel db", description = "inserisce una categoria nel db ")
	@ApiResponse(responseCode = "200" , description = "categoria inserita con successo nel db !")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisciCategoria" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciCategoria(@Valid @RequestBody InserisciCategoriaRequestDto dto) {
		cs.inserisciCategoria(dto);
			return ResponseEntity.ok("categoria inserita");}
	
	
	@Operation (summary = "ritorna la lista di categoria  nel db", description = "lista di categoria ")
	@ApiResponse(responseCode = "200" , description = "lista categoria")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated ")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttecategorie")
	public ResponseEntity tutteLeCategorie() {
		return ResponseEntity.ok(cs.trovaTutteLeCategorie());
	}
	
	
	
	@Operation (summary = "midifica una categoria  nel db", description = "modifica di una categoria")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta con successo")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificaCategoria")
	public ResponseEntity modificaCategoria(@Valid @RequestBody ModificaCategoriaRequestDTO dto) throws NotFoundException {
		cs.modificaCategoria(dto);
		return ResponseEntity.ok("categoria modificata");
	}
	
	
	@Operation (summary = "elimina una categoria  nel db", description = "eliminazione di una categoria")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta con successo")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminaCategoria/{id}")
	public ResponseEntity eliminaCategoria(@PathVariable("id") Long id ) throws NotFoundException {
		cs.eliminaCategoria(id);
		return ResponseEntity.ok("Categoria eliminato");
	}
	

}
