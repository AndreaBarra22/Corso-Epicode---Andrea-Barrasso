package it.epicode.libreria.dto;

import java.util.List;


import it.epicode.libreria.model.Categoria;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTutteLeCategorieResponseDTO {
	private int categorieTrovate;
	private List<Categoria> listaCategorie;
	
}
