package it.epicode.libreria.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciAutoreRequestDto {
	@NotBlank(message = "il nome è obbligatorio")
	private String nome;
	@NotBlank(message = "il cognome è obbligatorio")
	private String cognome;
}
