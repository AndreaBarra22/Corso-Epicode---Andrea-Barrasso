package it.epicode.libreria.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciCategoriaRequestDto {
	@NotBlank
	private String nome;
	@NotBlank
	private String categoria;
}
