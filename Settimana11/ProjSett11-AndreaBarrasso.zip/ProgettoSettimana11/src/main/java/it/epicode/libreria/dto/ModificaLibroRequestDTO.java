package it.epicode.libreria.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import it.epicode.libreria.model.Autore;
import it.epicode.libreria.model.Categoria;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaLibroRequestDTO {
	
	private Long id_libro;
	private String titolo;
	private int annoDiPubblicazione;
	private double prezzo;
	private String categoria;
	private String autore;

	
	
	
	
}
