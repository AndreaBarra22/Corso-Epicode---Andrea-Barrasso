package it.epicode.libreria.runner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.epicode.libreria.impl.ERole;
import it.epicode.libreria.impl.Role;
import it.epicode.libreria.impl.User;
import it.epicode.libreria.impl.UserRepository;
import it.epicode.libreria.model.Autore;
import it.epicode.libreria.model.Categoria;
import it.epicode.libreria.model.Libro;
import it.epicode.libreria.repository.AutoreRepository;
import it.epicode.libreria.repository.CategoriaRepository;
import it.epicode.libreria.repository.LibroRepository;

@Component
public class CatalogoRunner implements CommandLineRunner {
	
	@Autowired
	AutoreRepository ar;
	
	@Autowired
	CategoriaRepository cr;
	
	@Autowired
	LibroRepository lr;
	
	@Autowired
	PasswordEncoder encoder;
	
	@Autowired
	UserRepository ur;

	@Override
	public void run(String... args) throws Exception {

			
		Autore autore1 = Autore.builder().nome("Francesco").cognome("Donati").libri(new ArrayList<>()).build();
		Autore autore2 = Autore.builder().nome("Giovanni").cognome("Guarnieri").libri(new ArrayList<>()).build();
		
		Categoria categoria1 = Categoria.builder().nome("Giallo").libri(new ArrayList<>()).build();
		Categoria categoria2 = Categoria.builder().nome("Horror").libri(new ArrayList<>()).build();
	
		
		
		Libro libro1 = Libro.builder().titolo("Suburra").annoDiPubblicazione(2018).prezzo(23.50).autori(new ArrayList<>()).categoria(new ArrayList<>()).build();
		autore1.getLibri().add(libro1);
		libro1.getAutori().add(autore1);
		libro1.getCategoria().add(categoria1);	
		categoria1.getLibri().add(libro1);

		cr.save(categoria1);
		cr.save(categoria2);
		ar.save(autore1);
		ar.save(autore2);
		lr.save(libro1);
		
		
		
		
		Set hash = new HashSet<Role>();
		Role admin= Role.builder().roleName(ERole.ROLE_ADMIN).build();
		hash.add(admin);
		Set hash1 = new HashSet<Role>();
		Role user= Role.builder().roleName(ERole.ROLE_USER).build();
		hash1.add(user);
		User u1 = User.builder().username("mauro").password( BCrypt.hashpw("mauro", BCrypt.gensalt())).email("ciaociao@hotmail.it").roles(hash1).accountActive(true).build();
		User u = User.builder().username("giovanni").password(encoder.encode("maurito")).roles(hash).email("ciaocaio@hotmail.it").accountActive(true).build();
		ur.save(u);
		ur.save(u1);
		
	
	}

}
