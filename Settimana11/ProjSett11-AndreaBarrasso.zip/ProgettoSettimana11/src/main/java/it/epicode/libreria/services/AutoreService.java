package it.epicode.libreria.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import it.epicode.libreria.controller.AutoreController;
import it.epicode.libreria.dto.CercaTuttiGliAutoriResponseDTO;
import it.epicode.libreria.dto.CercaTuttiILibriResponseDTO;
import it.epicode.libreria.dto.InserisciAutoreRequestDto;
import it.epicode.libreria.dto.ModificaAutoreRequestDTO;
import it.epicode.libreria.errors.NotFoundException;
import it.epicode.libreria.model.Autore;
import it.epicode.libreria.model.Libro;
import it.epicode.libreria.repository.AutoreRepository;
import it.epicode.libreria.repository.LibroRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AutoreService {
@Autowired 
AutoreRepository ar;

	
	/**
	 * Inserimento di un autore
	 * @param dto
	 */

	public void inserisciAutore(InserisciAutoreRequestDto dto) {
		log.info("siamo nell'inserimento dell'autore");
		Autore a = new Autore();
		BeanUtils.copyProperties(dto, a);
		ar.save(a);
	}
	
	/**
	 * Ricerca di tutti gli autori
	 * @return
	 */
	
	public CercaTuttiGliAutoriResponseDTO trovaTuttiAutori() {
		log.info("siamo nella ricerca autori");
		CercaTuttiGliAutoriResponseDTO  dto = new CercaTuttiGliAutoriResponseDTO ();
		List<Autore> la = (List)ar.findAll(); 
		if(la.size()> 0) {
		dto.setAutoriTrovati(la.size());;
		dto.setElencoAutori(la);
			return dto;
		}
		return null;
	
	}
	
	
	/**
	 * Modifica di un autore
	 * @param dto
	 * @throws NotFoundException
	 */
	
	public void modificaAutore(ModificaAutoreRequestDTO dto) throws NotFoundException {
		log.info("siamo nel modifica autore");
		if(ar.existsById(dto.getId_autore())){
			Autore a = ar.findById(dto.getId_autore()).get();
			BeanUtils.copyProperties(dto, a);
			ar.save(a);
			}
		else { throw new NotFoundException("Autore non trovato");
			
		}
	}
	
	/**
	 * Eliminazione di un autore
	 * @param id
	 * @throws NotFoundException
	 */
	
	public void eliminaAutore(Long id) throws NotFoundException {
		log.info("siamo nell'elimina");
		if(ar.existsById(id)) {
			ar.deleteById(id);
			
		}
		else{ throw new NotFoundException("Autore inesistente");}

	}

	
	
	
	
	
	
}

