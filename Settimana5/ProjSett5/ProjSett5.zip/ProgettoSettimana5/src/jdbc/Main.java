package jdbc;

import java.util.Scanner;

import poliziaMunicipale.*;

public class Main {



	public static void main(String[] args) {
		
	
		
		System.out.println();
		System.out.println("Scegli cosa vuoi fare tra le seguenti opzioni :\n"
				
				
				+ "\n1: INSERISCI DATI AUTO \n" 
				+ "\n2: INSERISCI DATI INFRAZIONE \n"
				+ "\n3: VISUALIZZA TUTTE LE AUTO \n"
				+ "\n4: CERCA AUTO PER TARGA \n"
				+ "\n5: VISUALIZZA DATI INFRAZIONE \n"
				+ "\n6: ELIMINA INFRAZIONE");
		Scanner scannerScelta = new Scanner (System.in);
		int scelta = scannerScelta.nextInt();
		switch(scelta) {

		
		case 1:
			Scanner scanner = new Scanner(System.in);
			AutoDAO auto = new AutoDAO();
			System.out.println("INIZIALIZZA L'AUTO \n");
			System.out.println("Inserisci la targa  ");
			Scanner scannertarga = new Scanner (System.in);
			String targa = scannertarga.next();
			System.out.println("Inserisci la marca ");
			Scanner scannermarca = new Scanner (System.in);
			String marca = scannermarca.next();
			System.out.println("Inserisci il modello  ");
			Scanner scannermodello = new Scanner (System.in);
			String modello = scannermodello.next();
			Auto auto2 = new Auto(targa, marca, modello);
			auto.inserisciAuto(auto2);
			break;
			
			
			
		case 2:
		
			InfrazioneDAO infrazioni = new InfrazioneDAO();
			System.out.println("\nINIZIALIZZA L'INFRAZIONE: \n");
			System.out.println("Inserisci ID infrazione");
			Scanner scannerid = new Scanner (System.in);
			int id = scannerid.nextInt();
			System.out.println("Inserisci la data ");
			Scanner scannerdata= new Scanner (System.in);
			String data = scannerdata.next();
			System.out.println("Inserisci tipo  ");
			Scanner scannertipo = new Scanner (System.in);
			String tipo = scannertipo.next();
			System.out.println("Inserisci importo  ");
			Scanner scannerimporto = new Scanner (System.in);
			double importo = scannerimporto.nextDouble();
			System.out.println("Inserisci la targa ");
			Scanner scannerauto_targa = new Scanner (System.in);
			String auto_targa = scannerauto_targa.next();
			Infrazione infrazione1 = new Infrazione(id, data, tipo, importo, auto_targa);
			infrazioni.inserisciInfrazione(infrazione1);
			break;
			
		case 3:
			AutoDAO autoMax = new AutoDAO();
			autoMax.getAllAuto();
			break;
			
		case 4:
			AutoDAO autoTarga = new AutoDAO();
			autoTarga.cercaAuto("");
			break;
		case 5:
			InfrazioneDAO infrazioni2 = new InfrazioneDAO();
			infrazioni2.stampaDatiInfrazioniAuto();
			break;
		case 6:
			InfrazioneDAO infrazioniId = new InfrazioneDAO();
			 id= 0;
			infrazioniId.eliminaInfrazione(id);
			break;
		}
		
	}
}


