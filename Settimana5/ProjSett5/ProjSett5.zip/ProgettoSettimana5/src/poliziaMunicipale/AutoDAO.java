package poliziaMunicipale;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import jdbc.ConnectionFactory;

public class AutoDAO {
	public boolean inserisciAuto(Auto auto) {
		Connection connessione = ConnectionFactory.getConnection();
		String query = "INSERT INTO auto (targa, marca, modello) VALUES (?, ?, ?)";
		boolean inserisciA = false;
		PreparedStatement ps = null;

		try {
			ps = connessione.prepareStatement(query);
			ps.setString(1, auto.getTarga());
			ps.setString(2, auto.getMarca());
			ps.setString(3, auto.getModello());
			inserisciA = ps.execute();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		if(inserisciA = true) {

			System.out.println("L'auto è stata importata con successo");


		}

		else {

			System.out.println("L'auto non è stata importata, riprova");
		}
		return inserisciA = true;


	}
	public ArrayList<Auto> getAllAuto() {
		Connection connessione = ConnectionFactory.getConnection();
		try {
			Statement statement = connessione.createStatement();
			String query = "SELECT * from auto";
			ResultSet risultato = statement.executeQuery(query);
			ArrayList<Auto> allAuto = new ArrayList<>(); 

			while (risultato.next()) {
				String targa = risultato.getString("targa");
				String marca = risultato.getString("marca");
				String modello = risultato.getString("modello");
				Auto auto = new Auto(targa, marca, modello);
				allAuto.add(auto);
				System.out.println("\n"+targa + " " + marca + " " + modello +  " " + "\n");

			}
			return allAuto;


		} catch (SQLException e) {

			e.printStackTrace();
		} 
		finally {

			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		return null;





	}

	public Auto cercaAuto(String targaAuto) {
		Connection connessione = ConnectionFactory.getConnection();
		String query = "SELECT * from auto where targa = ? ";

		PreparedStatement ps = null;
		System.out.println("Inserisci la targa dell'auto: ");
		Scanner in = new Scanner (System.in);
		String targa = in.next();
		try {
			ps = connessione.prepareStatement(query);
			ps.setString(1, targa);
			ResultSet rs = ps.executeQuery();
			
			
			if(rs.next()) {
				String marca = rs.getString("marca");
				String modello = rs.getString("modello");
				Auto auto = new Auto(targa, marca, modello);
				System.out.println("\nL'auto che cerchi è la seguente:\n"+"\n"+ targa + " " + marca + " " + modello +  " " + "\n");
				return auto;
			}
			else {
				System.out.println("La targa che hai inserito non corrispondo con nessun'auto, riprova!");
			}
			
		
			




		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
			return null;




		
	}
}







	
	