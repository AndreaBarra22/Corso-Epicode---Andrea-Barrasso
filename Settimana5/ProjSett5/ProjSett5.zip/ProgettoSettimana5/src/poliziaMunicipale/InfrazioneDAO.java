package poliziaMunicipale;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import jdbc.ConnectionFactory;

public class InfrazioneDAO {
	public boolean inserisciInfrazione(Infrazione infrazione) {
		Connection connessione = ConnectionFactory.getConnection();
		String query = "INSERT INTO infrazione (id, data, tipo, importo, auto_targa) VALUES (?, ?, ?, ?, ?)";
		boolean inserisciI = false;
		PreparedStatement ps = null;
		try {
			ps = connessione.prepareStatement(query);
			ps.setInt(1, infrazione.getId());
			ps.setString(2, infrazione.getData());
			ps.setString(3, infrazione.getTipo());
			ps.setDouble(4, infrazione.getImporto());
			ps.setString(5, infrazione.getAuto_targa());
			inserisciI = ps.execute();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		if(inserisciI = true) {
			System.out.println("\nL'INFRAZIONE E' STATA INSERITA CON SUCCESSO");
		}
		else {
			System.out.println("\nL'INFRAZIONE NON E' STATA INSERITA, RIPROVA");
		}
		return inserisciI = true;

	}
	public void stampaDatiInfrazioniAuto() {
		Connection connessione = ConnectionFactory.getConnection();
		try {
		
			Statement statement = connessione.createStatement();
			String query = "SELECT * from auto JOIN infrazione on auto.targa = infrazione.auto_targa";
			ResultSet risultato = statement.executeQuery(query);
		
			while (risultato.next()) {
				
				int id  = risultato.getInt("id");
				String data = risultato.getString("data");
				String tipo = risultato.getString("tipo");
				double importo = risultato.getDouble("importo");
				String auto_targa = risultato.getString("auto_targa");
				String marca = risultato.getString("marca");
				String modello = risultato.getString("modello");
				System.out.println(id + " DATA: " + data + " TIPO: " + tipo +  " IMPORTO: " + importo + " TARGA: " + auto_targa + " MARCA: " + marca + " MODELLO: " + modello + " " +  "\n");
				
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}
	public boolean eliminaInfrazione(int id) {
		Connection connessione = ConnectionFactory.getConnection();
		String query = "DELETE from infrazione where id = ?";
		boolean eliminaI = false;
		PreparedStatement ps = null;
		 System.out.println("\nINSERISCI L'ID DELL'INFRAZIONE CHE DESIDERI ELIMINARE: ");
		 Scanner in = new Scanner (System.in);
		 id = in.nextInt();
		try {
			ps = connessione.prepareStatement(query);
			ps.setInt(1, id);
			eliminaI = ps.execute();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		if(eliminaI = true) {
			System.out.println("\nL'INFRAZIONE E' STATA ELIMINATA CON SUCCESSO");
		}
		else {
			System.out.println("\nL'INFRAZIONE NON E' STATA ELIMINATA, RIPROVA");
		}
		return eliminaI = true;
	}


}
