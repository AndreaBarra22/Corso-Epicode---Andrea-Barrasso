package it.business;
import it.data.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import it.data.ConnectionFactory;
import it.data.ContoCorrente;
import it.data.ContoCorrenteDAO;
import jakarta.ejb.EJB;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;



/**
 * Session Bean implementation class BancomatEJB
 */

@Stateless
@LocalBean
public class BancomatEJB {
	private ContoCorrenteDAO cd;

	/**
	 * Default constructor. 
	 */
	public BancomatEJB() {
		this.cd = new ContoCorrenteDAO();
		// TODO Auto-generated constructor stub

	}
	public boolean controllaVersa(String operazione, int numeroconto, float saldo) {

		return cd.controllaVersa(operazione, numeroconto, saldo);

	}
	public boolean controllaPreleva(String operazione, int numeroconto, float saldo) {
		return cd.controllaPreleva(operazione, numeroconto, saldo);


	}
	public ContoCorrente getContoCorrente(int numeroconto) {
		return cd.getContoCorrente(numeroconto);

	}
	public  boolean versa(int numeroconto, float saldo) {
		return cd.versa(numeroconto, saldo);
	}
	public  boolean preleva(int numeroconto, float saldo) {
		return cd.preleva(numeroconto, saldo);
	}
	public boolean esiste(int numeroconto) {
		return cd.esiste(numeroconto);
	}
	public boolean inserisciConto(int numeroconto,  float saldo,String intestatario) {
		return cd.inserisciConto(numeroconto, saldo,intestatario);
	}


}



