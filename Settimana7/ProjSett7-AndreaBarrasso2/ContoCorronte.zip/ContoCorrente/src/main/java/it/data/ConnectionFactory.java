package it.data;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionFactory {
	
	public static final String URL = "jdbc:postgresql://localhost:5432/bancadb";
	public static final String USER = "postgres";
	public static final String PASSWORD = "12345";
	

	public static Connection getConnection() {
		Connection connessione = null;
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}
		try {
			connessione = DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connessione;
	}
}
