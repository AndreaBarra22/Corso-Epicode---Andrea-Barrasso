package it.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import it.business.BancomatEJB;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * 
     */
	@EJB
   BancomatEJB bejb;
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int numeroconto = Integer.parseInt(request.getParameter("numeroconto"));
        float saldo = Float.parseFloat(request.getParameter("saldo"));
        String intestatario = request.getParameter("intestatario");

        boolean ok = false;

        String msg = "";
       ok=	bejb.esiste(numeroconto);
       ok = bejb.inserisciConto(numeroconto,saldo, intestatario);
        if(ok) {

            msg = "operazione effettuata";
        }	
        else {
            msg="Si e verificato un errore";
        }
        request.setAttribute("success", ok);
        request.setAttribute("messaggio", msg);
        request.setAttribute("intestatario", intestatario);
        request.setAttribute("numeroconto",numeroconto);
        request.setAttribute("saldo",saldo);

        request.getServletContext().getRequestDispatcher("/WEB-INF/jsp2/registrazione.jsp").forward(request, response);

    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
