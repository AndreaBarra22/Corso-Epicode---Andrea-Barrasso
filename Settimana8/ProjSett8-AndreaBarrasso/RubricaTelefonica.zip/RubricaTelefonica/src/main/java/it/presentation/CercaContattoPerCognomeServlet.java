package it.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;



import it.business.RubricaEJB;
import it.model.Contatto;

/**
 * Servlet implementation class CercaContattoPerCognomeServlet
 */
public class CercaContattoPerCognomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	@EJB
	RubricaEJB rejb;
    public CercaContattoPerCognomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String cognome = request.getParameter("cognome");
		
		
		
		List<Contatto> lc = rejb.cercaContattoPerCognome(cognome);
		
		response.getWriter().append("Lista Contatti").append("<br>");
		for(Contatto c: lc) {
			response.getWriter()
			.append(c.getNome())
			.append(" ")
			.append(c.getCognome())
			.append(" ")
			.append(c.getEmail())
			.append(" ")
			.append((CharSequence) c.getNumTelefoni())
			.append("<br>")
			;
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

}
