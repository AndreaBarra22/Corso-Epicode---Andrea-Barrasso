package it.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import it.business.RubricaEJB;
import it.model.Contatto;

/**
 * Servlet implementation class CercaContattoPerNumero
 */
public class CercaContattoPerNumero extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	@EJB
	RubricaEJB rejb;
    public CercaContattoPerNumero() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String numero1 = request.getParameter("numero1");
		String numero2 = request.getParameter("numero2");
		
		List<Contatto> lc = rejb.cercaContattoPerNumero(numero1, numero2);
		
		response.getWriter().append("Lista Contatti").append("<br>");
		for(Contatto c: lc) {
			response.getWriter()
			.append(c.getNome())
			.append(" ")
			.append(c.getCognome())
			.append(" ")
			.append(c.getEmail())
			.append(" ")
			.append((CharSequence) c.getNumTelefoni())
			.append("<br>")
			;
		}
	}

}
