package it.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import it.business.RubricaEJB;

/**
 * Servlet implementation class ModificaNumeroContattoServlet
 */
public class ModificaNumeroContattoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	@EJB
	RubricaEJB rejb;
    public ModificaNumeroContattoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
		String numero1 = request.getParameter("numero1");
		String numero2 = request.getParameter("numero2");
		
		
		
		rejb.modificaNumeroContatto(id, nome, cognome, email, numero1, numero2);
		
		response.getWriter().append("Contatto ")
		.append(id)
		.append(" ")
		.append(nome)
		.append(" ")
		.append(cognome)
		.append( " ")
		.append(email)
		.append(" ")
		.append(numero1)
		.append(" ")
		.append(numero2)
		.append(" ")
		.append("Contatto modificato ");
	}
		

}
