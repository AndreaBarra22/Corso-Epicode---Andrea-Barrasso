package it.epicode.film.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class InserisciFilmRequestDTO {
	@NotBlank(message = "iIl campo TITOLO deve essere compilato obbligatoriamente!!!")
	private String titolo;
	@NotBlank(message = "Il campo ANNO deve essere compilato obbligatoriamente!!!")
	private String anno;
	@NotBlank(message = "Il campo REGISTA deve essere compilato obbligatoriamente!!!")
	private String regista;
	@NotBlank(message = "Il campo TIPO deve essere compilato obbligatoriamente!!!")
	private String tipo;
	@NotBlank(message = "Il campo INCASSO deve essere compilato obbligatoriamente!!!")
	private String incasso;

}
