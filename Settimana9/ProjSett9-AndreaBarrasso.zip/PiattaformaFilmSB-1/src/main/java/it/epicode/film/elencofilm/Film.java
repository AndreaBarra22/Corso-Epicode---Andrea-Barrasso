package it.epicode.film.elencofilm;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;



import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Film {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@NotNull(message = "Il campo TITOLO deve essere compilato obbligatoriamente!!!")
	private String titolo;
	@NotNull(message = "Il campo ANNO deve essere compilato obbligatoriamente!!!")
	private String anno;
	@NotNull(message = "Il campo REGISTA deve essere compilato obbligatoriamente!!!")
	private String regista;
	@NotNull(message = "Il campo TIPO deve essere compilato obbligatoriamente!!!")
	private String tipo;
	@NotNull(message = "Il campo INCASSO deve essere compilato obbligatoriamente!!!")
	private String incasso;


}
