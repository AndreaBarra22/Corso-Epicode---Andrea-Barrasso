package it.epicode.film.elencofilm;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.film.dto.InserisciFilmRequestDTO;
import it.epicode.film.dto.ModificaFilmRequestDTO;
import it.epicode.film.services.FilmService;

/**
 * Servizi rest relativi alla classe film
 * @author Andrea Barrasso
 * 
 */


@RestController
@RequestMapping("/film")
@Tag(name = "film rest services", description = "implementazioni delle api rest dei film")
public class FilmController {
	@Autowired
	FilmRepository fr;
	@Autowired
	FilmService fs;

	/**
	 * Inserimento nel db di un film
	 * @param c
	 * @param errori
	 * @return
	 */

	@Operation (summary = "Inserisce un	Film nel db", description = "inserisce un Film nel db ")
	@PostMapping(path = "/inserisci" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciFilm(@Valid @RequestBody InserisciFilmRequestDTO dto, BindingResult errori) {

		if(errori.hasErrors()) {
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
		}
		if(fs.inserisciFilm(dto)) {
			return ResponseEntity.ok("Film inserito con successo");}
		else {return new ResponseEntity("errore nell'inserimento!!!", HttpStatus.FAILED_DEPENDENCY);}
	}




	/**
	 * Ricerca di un film nel db attraverso l'id passato in input
	 * 
	 * @param id
	 * @return
	 */
	
	
	@Operation (summary = "cerca un	film nel db", description = "cerca un Film nel db tramite id ")
	@GetMapping("/cercaPerId/{id}")
	public ResponseEntity cercaPerId(@PathVariable("id") int id) {
		if(fr.existsById(id)) {
			return ResponseEntity.ok(fs.trovaTuttiIFilmPerId(id));}
		else {
			return new ResponseEntity("Nessun Film trovato!!!", HttpStatus.NOT_FOUND);
		}
	}



	/**
	 * Ritorna tutti i film presenti nel db 
	 * @return
	 */
	
	
	@Operation (summary = "ritorna tutti i 	Film nel db", description = "ritorna tutti i Film presenti nel db ")
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity tuttiIFilm() {
		return ResponseEntity.ok(fr.findAll());
	}
	/**
	 * Ricerca nel database di un Film attraverso il cognome dato in input
	 * associato ad un metodo GET
	 * @param cognome
	 * @return
	 */
	
	
	@Operation (summary = "cerca  film tramite regista", description = "cerca un film nel db tramite regista")
	@GetMapping("/cercaPerRegista/{regista}")
	public ResponseEntity cercaPerRegista(@PathVariable("regista") String regista) {
		return ResponseEntity.ok(fs.trovaTuttiIFilmPerRegista(regista));

	}





	/**
	 * Rimozione dei film presenti nel db attraverso l'id passato in input
	 * @param id
	 * @return
	 */
	
	
	@Operation (summary = "elimina un Film nel db", description = "elimina un Film nel db tramite l'id ")
	@DeleteMapping("/eliminaFilm/{id}")
	public ResponseEntity cancellaFilm(@PathVariable ("id") int id ) {
		if(fr.existsById(id)) {
			fr.deleteById(id);
			return ResponseEntity.ok("Film eliminato con successo");}
		else {
			return  new ResponseEntity("Film non trovato!!! ", HttpStatus.NOT_FOUND);
		}



	}
	/**
	 * Esegue un update del film
	 * associato ad un metodo mapping put
	 * @param id
	 * @param c
	 * @return
	 */
	
	
	@Operation (summary = "Modifica un Film nel db", description = "Modifica un Film nel db tramite l'id ")
	@PutMapping( produces = MediaType.TEXT_PLAIN_VALUE, path = "/modificafilm/{id}")
	public ResponseEntity modificaFilm(@Valid @PathVariable("id")int id,@RequestBody ModificaFilmRequestDTO dto, BindingResult errori) {

		if(errori.hasErrors()) {
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);

		}
		if(fs.ModificaFilm(dto)) {
			return ResponseEntity.ok("Film modificato");}
		else {return new ResponseEntity("il film non esiste", HttpStatus.FAILED_DEPENDENCY);}

	}

}
