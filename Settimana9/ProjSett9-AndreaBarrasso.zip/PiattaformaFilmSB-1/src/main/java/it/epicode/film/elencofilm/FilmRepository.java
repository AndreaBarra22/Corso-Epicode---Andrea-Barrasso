package it.epicode.film.elencofilm;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
/**
 * repository classe film
 * @author Andrea Barrasso
 */
public interface FilmRepository extends CrudRepository<Film, Integer> {
	
	
	/**
	 * Ricerca i film per regista con in input il regista
	 * 
	 * @param regista
	 * @return una lista di film con il regista passato in input
	 */
	
	
	public List<Film> findByRegista(String regista);



}
