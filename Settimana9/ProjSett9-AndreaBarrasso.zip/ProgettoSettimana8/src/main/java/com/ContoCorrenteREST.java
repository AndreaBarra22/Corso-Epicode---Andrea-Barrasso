package com;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import model.ContoCorrente;

@Path("/conto_corrente")
public class ContoCorrenteREST {

	private static List<ContoCorrente> conticorrenti = new ArrayList<>();
	

	@POST
	@Path("/inserimentocontocorrente")
	@Consumes (MediaType.APPLICATION_JSON)
	@Produces (MediaType.APPLICATION_JSON)
	public Response creaContoCorrente(ContoCorrente cc) {
		String result = "";
		if(!conticorrenti.contains(cc)) {
		conticorrenti.add(cc);
		result = "Il conto è stato creato con successo ";
		return Response.status(201).entity(result).build();}
		else {
			result ="Il conto è gia esistente!!! ";
			return Response.status(404).entity(result).build();
		}

	}
	
	
	@PUT
	@Path("/aggiornacontocorrente")
	@Consumes (MediaType.APPLICATION_JSON)
	@Produces (MediaType.APPLICATION_JSON)
	public Response aggiornaContoCorrente(ContoCorrente cc) {
		String result = "";
		if(conticorrenti.contains(cc))
		{
			int index = conticorrenti.indexOf(cc);

			conticorrenti.set(index, cc);
			result= " L'aggiornamento del conto avvenuto con successo";
			return Response.status(200).entity(result).build();
		}else {
			result ="L'aggiornamento non è andato a buon fine, riprova!!! ";
			return Response.status(404).entity(result).build();
		}

	}
	
	
	
	

	@PUT
	@Path("/prelievo/{prelievo}")
	@Consumes (MediaType.APPLICATION_JSON)
	@Produces (MediaType.APPLICATION_JSON)
	public Response prelievo1(@PathParam("prelievo") double saldo, ContoCorrente cc) {
		String result = "";
		String operazione ="";
		if(conticorrenti.contains(cc))
		{
			int index = conticorrenti.indexOf(cc);
			if(cc.getSaldo() > saldo) {
				cc.setSaldo(cc.getSaldo()-saldo);
				conticorrenti.set(index, cc);
				result= "Prelievo avvenuto con successo!"
						+ "prelevati: "+ saldo;
						
				operazione ="prelievo";
				cc.listamovimenti(operazione, saldo);


				return Response.status(200).entity(result).build();
			}
			else {
				result ="Prelievo non riuscito ";
				return Response.status(404).entity(result).build();
			}



		}
		else {
			result = "ContoCorrente inesistente";
			return Response.status(404).entity(result).build();
		}

	}



	@PUT
	@Path("/versamento/{versamento}")
	@Consumes (MediaType.APPLICATION_JSON)
	@Produces (MediaType.APPLICATION_JSON)
	public Response versamento(@PathParam("versamento") double saldo, ContoCorrente cc) {
		String result = "";
		String operazione ="";
		if(conticorrenti.contains(cc))
		{
			int index = conticorrenti.indexOf(cc);
			if(saldo >= 0) {
				cc.setSaldo(saldo + cc.getSaldo());
				conticorrenti.set(index, cc);
				result= "Versamento avvenuto con successo!"
						+ "Saldo versato: " + saldo ;
				operazione ="versamento";
				cc.listamovimenti(operazione, saldo);

				return Response.status(200).entity(result).build();
			}
			else {
				result ="Versamento non riuscito ";
				return Response.status(404).entity(result).build();
			}



		}
		else {
			result = "ContoCorrente inesistente";
			return Response.status(404).entity(result).build();
		}

	}
	@DELETE
	@Path("/{iban}")
	public Response elimina(@PathParam("iban") int iban) {
		String result = "";
		for (ContoCorrente cc : conticorrenti) {
			if(cc.getIban() == iban) {
				conticorrenti.remove(cc);
				result = "Eliminazione avvenuta con successo";
				return Response.status(200).entity(result).build();
			}
			else {
				result = "Eliminazione non avvenuta!!!!";
				return Response.status(404).entity(result).build();

			}

		}
		return null;
	}

	@GET
    @Path("/intestatario/{intestatario}")
    @Produces(MediaType.APPLICATION_JSON)
    public ContoCorrente ricercaPerIntestatario(@PathParam("intestatario") String intestatario ) {
        ContoCorrente cc1 = new ContoCorrente();
        for (ContoCorrente cc : conticorrenti) {
            if(cc.getIntestatario().equals(intestatario)) {
                cc1 = cc;
            }
            else {
            	Response.status(404).entity("Il conto non esiste").build();
            }
            
        }
        return cc1;
    }

	@GET
	@Path("/tutticonti")
	@Produces (MediaType.APPLICATION_JSON)
	public List<ContoCorrente> tutticonti(){
		return conticorrenti;
	}


}








