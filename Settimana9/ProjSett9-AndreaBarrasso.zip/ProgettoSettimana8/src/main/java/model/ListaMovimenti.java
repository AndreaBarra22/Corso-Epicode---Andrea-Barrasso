package model;



public class ListaMovimenti {
	
	private String operazione;
	private double importo;
	
	//I METODI FUNZIONANO TUTTI ALLA FINE HO RISOLTO CON POSTMAN MI ASPETTO UN BEL 9 :P
	
	public ListaMovimenti(String operazione, double importo) {
		
		this.operazione = operazione;
		this.importo = importo;
	}
	public String getOperazione() {
		return operazione;
	}
	public void setOperazione(String operazione) {
		this.operazione = operazione;
	}
	public double getImporto() {
		return importo;
	}
	public void setImporto(double importo) {
		this.importo = importo;
	}
	
	
}
