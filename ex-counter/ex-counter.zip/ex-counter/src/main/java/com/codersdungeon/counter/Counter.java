package com.codersdungeon.counter;

public class Counter {

	private int base;
	private int digits;
	private int[] current;
	private String maxValue = "";

	private Counter(int base, int digits) {
		this.base = base;
		this.digits = digits;
		current = new int[digits];
		for (int i = 0; i < digits; i++)
			maxValue += "" + (base - 1);
	}

	public static Counter createCounter(int base, int digits) {
		if (base <= 1 || digits <= 0)
			throw new IllegalArgumentException();
		return new Counter(base, digits);
	}

	public int getBase() {
		return base;
	}

	public int getDigits() {
		return digits;
	}

	public String current() {
		String result = "";
		for (int i : current)
			result += "" + i;
		return result;

	}

	public String maxValue() {
		for (int i = 0; i < digits; i++)
			maxValue += "" + (base - 1);
		return maxValue;
	}

	public String next() {
		return null;
	}

	public int getDecimalValue() {

		return 0;
	}
}
