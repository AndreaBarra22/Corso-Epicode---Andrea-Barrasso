package Main;

import java.util.ArrayList;
import java.util.HashMap;

import scuola.Scuola;
import scuola.Studente;

public class Main {

	public static void main(String[] args) {

		HashMap<String, ArrayList<Integer>> votiStudenti = new HashMap<String, ArrayList<Integer>>();

		// arraylist dei voti
		ArrayList<Integer> votiMatematica = new ArrayList<>();
		ArrayList<Integer> votiItaliano = new ArrayList<>();
		ArrayList<Integer> votiChimica = new ArrayList<>();
		ArrayList<Integer> votiInformatica = new ArrayList<>();

		// hashmap delle materie e voti
		votiStudenti.put("Matematica", votiMatematica);
		votiStudenti.put("Italiano", votiItaliano);
		votiStudenti.put("Chimica", votiChimica);
		votiStudenti.put("Informatica", votiInformatica);

		// studenti scuola1
		Studente studente1 = new Studente(1, "Angelo", "Duro", 'M', 7);
		Studente studente2 = new Studente(2, "Simone", "Lallero", 'M', 5);
		Studente studente3 = new Studente(3, "Giulia", "Ninni", 'F', 8);
		Studente studente4 = new Studente(4, "Ninna", "Nanna", 'F', 10);
		Studente studente5 = new Studente(5, "Justin", "Bieber", 'M', 3);

		// studenti scuola2
		Studente studente6 = new Studente(6, "Kizaru", "Borsalino", 'M', 7);
		Studente studente7 = new Studente(7, "Andrea", "Barbone", 'M', 9);
		Studente studente8 = new Studente(8, "Acquetta", "Ferrarelle", 'M', 4);
		Studente studente9 = new Studente(9, "Maurizio", "Dringhi", 'M', 10);
		Studente studente10 = new Studente(10, "Madre", "Diddio", 'F', 6);

		// Scuola1
		ArrayList<Studente> studenti = new ArrayList<>();
		studenti.add(studente1);
		studenti.add(studente2);
		studenti.add(studente3);
		studenti.add(studente4);
		studenti.add(studente5);

		// Scuola2
		ArrayList<Studente> studenti2 = new ArrayList<>();
		studenti2.add(studente6);
		studenti2.add(studente7);
		studenti2.add(studente8);
		studenti2.add(studente9);
		studenti2.add(studente10);

		// scuola1
		Scuola scuola = new Scuola(studenti);
		// scuola2
		Scuola scuola2 = new Scuola(studenti2);

		// System.out.println(scuola);
		// System.out.println(scuola2);

		System.out.println(studente2.promosso());
	}

}
