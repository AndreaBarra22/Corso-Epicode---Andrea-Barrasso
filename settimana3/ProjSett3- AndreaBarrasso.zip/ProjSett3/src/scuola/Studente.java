package scuola;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Studente {

	private int id;
	private String nome;
	private String cognome;
	private char genere;
	HashMap<String, ArrayList<Double>> voti;

	public Studente(int id, String nome, String cognome, char genere, int voti) {
		super();
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.genere = genere;

	}

	public Studente(String string, String string2, String string3, String string4) {
	}

	public int getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public String getCognome() {
		return cognome;
	}

	public char getGenere() {
		return genere;
	}

	public HashMap<String, ArrayList<Double>> getVoti() {
		return voti;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public void setGenere(char genere) {
		this.genere = genere;
	}

	public void setVotiStudente(HashMap<String, ArrayList<Double>> voti) {
		this.voti = voti;
	}

	public double mediaVotoMateria(String materia) {
		HashMap<String, ArrayList<Double>> voti = null;
		ArrayList<Double> votiMateria = new ArrayList<>(voti.get(materia));
		double somma = 0;
		for (Double voto : votiMateria) {
			somma += voto;
		}
		return somma / votiMateria.size();
	}

	public double VotoMiglioreMateria(String materia) {
		ArrayList<Double> votiMateria = new ArrayList<>(voti.get(materia));
		Double votoMigliore = votiMateria.get(0);
		for (Double voto : votiMateria) {
			if (votoMigliore < voto) {
				votoMigliore = voto;

			}
		}
		return votoMigliore;

	}

	public boolean promosso() {
		int materieInsufficienti = 0;
		for (String i : this.voti.keySet()) {
			if (mediaVotoMateria(i) < 6) {
				materieInsufficienti++;

			}

		}
		if (materieInsufficienti >= 4) {
			return false;

		}
		return true;

	}

}
